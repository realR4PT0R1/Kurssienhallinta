<?php
include 'db.php';

$kurssi_id = $_GET['id'];

$sql = "SELECT kurssit.*, opettajat.Etunimi, opettajat.Sukunimi, tilat.Nimi as Tila
        FROM kurssit
        JOIN opettajat ON kurssit.Opettaja = opettajat.Tunnusnumero
        JOIN tilat ON kurssit.Tila = tilat.Tunnus
        WHERE kurssit.Tunnus = '$kurssi_id'";

$result = $conn->query($sql);
$kurssi = $result->fetch_assoc();

$sql_opiskelijat = "SELECT opiskelijat.nimi, vuosikurssi FROM ilmoittautumiset 
                   JOIN opiskelijat ON ilmoittautumiset.opiskelija_id = opiskelijat.opiskelija_id 
                   WHERE kurssi_id = '$kurssi_id'";
$result_opiskelijat = $conn->query($sql_opiskelijat);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Kurssin tiedot</title>
</head>

<body>
    <h1><?php echo $kurssi['Kurssi']; ?></h1>
    <p><strong>Kuvaus:</strong> <?php echo $kurssi['Kuvaus']; ?></p>
    <p><strong>Alku:</strong> <?php echo $kurssi['Alkupäivä']; ?></p>
    <p><strong>Loppu:</strong> <?php echo $kurssi['Loppupäivä']; ?></p>
    <p><strong>Opettaja:</strong> <?php echo $kurssi['Etunimi'] . ' ' . $kurssi['Sukunimi']; ?></p>
    <p><strong>Tila:</strong> <?php echo $kurssi['Tila']; ?></p>

    <h2>Ilmoittautuneet opiskelijat</h2>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Vuosikurssi</th>
        </tr>
        <?php
        if ($result_opiskelijat->num_rows > 0) {
            while ($row = $result_opiskelijat->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['nimi']}</td>
                    <td>{$row['vuosikurssi']}</td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='2'>Ei opiskelijoita</td></tr>";
        }
        ?>
    </table>
</body>

</html>