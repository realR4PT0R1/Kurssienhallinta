<?php
include 'db.php';

$kurssi_id = $_GET['id'];

$sql = "SELECT kurssit.nimi AS kurssin_nimi, kuvaus, alku_pvm, loppu_pvm, opettajat.nimi AS opettajan_nimi, tilat.nimi AS tilan_nimi 
        FROM kurssit 
        JOIN opettajat ON kurssit.opettaja_id = opettajat.opettaja_id
        JOIN tilat ON kurssit.tila_id = tilat.tila_id
        WHERE kurssi_id = '$kurssi_id'";
$result = $conn->query($sql);
$kurssi = $result->fetch_assoc();

$sql_opiskelijat = "SELECT opiskelijat.nimi, vuosikurssi FROM ilmoittautumiset 
                   JOIN opiskelijat ON ilmoittautumiset.opiskelija_id = opiskelijat.opiskelija_id 
                   WHERE kurssi_id = '$kurssi_id'";
$result_opiskelijat = $conn->query($sql_opiskelijat);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kurssin tiedot</title>
</head>
<body>
    <h1><?php echo $kurssi['kurssin_nimi']; ?></h1>
    <p><strong>Kuvaus:</strong> <?php echo $kurssi['kuvaus']; ?></p>
    <p><strong>Alku:</strong> <?php echo $kurssi['alku_pvm']; ?></p>
    <p><strong>Loppu:</strong> <?php echo $kurssi['loppu_pvm']; ?></p>
    <p><strong>Opettaja:</strong> <?php echo $kurssi['opettajan_nimi']; ?></p>
    <p><strong>Tila:</strong> <?php echo $kurssi['tilan_nimi']; ?></p>

    <h2>Ilmoittautuneet opiskelijat</h2>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Vuosikurssi</th>
        </tr>
        <?php
        if ($result_opiskelijat->num_rows > 0) {
            while($row = $result_opiskelijat->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['nimi']}</td>
                        <td>{$row['vuosikurssi']}</td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='2'>Ei opiskelijoita</td></tr>";
        }
        ?>
    </table>
</body>
</html>
