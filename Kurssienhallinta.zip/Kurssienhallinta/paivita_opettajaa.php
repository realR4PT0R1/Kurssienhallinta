<?php
include 'db.php';  // Yhdistetään tietokantaan

// Tarkistetaan, että id, etunimi, sukunimi ja aine on asetettu
if (isset($_POST['id'], $_POST['etunimi'], $_POST['sukunimi'], $_POST['aine'])) {
    // Haetaan POST-muuttujat
    $id = $_POST['id'];
    $etunimi = $_POST['etunimi'];
    $sukunimi = $_POST['sukunimi'];
    $aine = $_POST['aine'];

    // Varmistetaan, että kaikki kentät eivät ole tyhjiä
    if (!empty($etunimi) && !empty($sukunimi) && !empty($aine)) {
        // Suoritetaan SQL-kysely, joka päivittää opettajan tiedot
        $sql = "UPDATE opettajat SET Etunimi = ?, Sukunimi = ?, Aine = ? WHERE Tunnusnumero = ?";

        // Valmistellaan ja suojataan kysely SQL-injektioita vastaan
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sssi", $etunimi, $sukunimi, $aine, $id);

            // Suoritetaan kysely
            if ($stmt->execute()) {
                echo "Opettajan tiedot päivitettiin onnistuneesti.";
            } else {
                echo "Tiedon päivitys epäonnistui: " . $stmt->error;
            }

            // Suljetaan lauseke
            $stmt->close();
        } else {
            echo "Virhe kyselyssä: " . $conn->error;
        }
    } else {
        echo "Kaikki kentät ovat pakollisia!";
    }
} else {
    echo "Virheelliset tiedot. Yritä uudelleen.";
}

// Suljetaan tietokantayhteys
$conn->close();
?>