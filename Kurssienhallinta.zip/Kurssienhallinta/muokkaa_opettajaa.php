<?php
include 'db.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $aine = $_POST['aine'];

    $sql = "UPDATE opettajat SET nimi='$nimi', aine='$aine' WHERE opettaja_id='$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: opettajat.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
} else {
    $sql = "SELECT * FROM opettajat WHERE opettaja_id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Muokkaa opettajaa</title>
</head>
<body>
    <h1>Muokkaa opettajaa</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" value="<?php echo $row['nimi']; ?>" required><br>
        Aine: <input type="text" name="aine" value="<?php echo $row['aine']; ?>" required><br>
        <input type="submit" value="Tallenna">
    </form>
</body>
</html>
