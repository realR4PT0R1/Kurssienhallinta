<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Haetaan opettajan tiedot
    $sql = "SELECT * FROM opettajat WHERE Tunnusnumero = $id"; // Oikea sarake
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc(); // Oletetaan, että taulukko on täytetty
    } else {
        echo "Opettajaa ei löytynyt.";
        exit();
    }
} else {
    echo "Virheellinen ID.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Muokkaa opettajaa</title>
</head>

<body>

    <h1>Muokkaa opettajaa</h1>

    <form action="paivita_opettajaa.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['Tunnusnumero']; ?>">

        <label for="etunimi">Etunimi:</label>
        <input type="text" id="etunimi" name="etunimi"
            value="<?php echo isset($row['Etunimi']) ? htmlspecialchars($row['Etunimi']) : ''; ?>" required>
        <br>

        <label for="sukunimi">Sukunimi:</label>
        <input type="text" id="sukunimi" name="sukunimi"
            value="<?php echo isset($row['Sukunimi']) ? htmlspecialchars($row['Sukunimi']) : ''; ?>" required>
        <br>

        <label for="aine">Aine:</label>
        <input type="text" id="aine" name="aine"
            value="<?php echo isset($row['Aine']) ? htmlspecialchars($row['Aine']) : ''; ?>" required>
        <br>

        <button type="submit">Tallenna muutokset</button>
    </form>

</body>

</html>