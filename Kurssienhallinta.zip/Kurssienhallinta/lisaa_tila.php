<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $kapasiteetti = $_POST['kapasiteetti'];

    $sql = "INSERT INTO tilat (nimi, kapasiteetti) VALUES ('$nimi', '$kapasiteetti')";

    if ($conn->query($sql) === TRUE) {
        header("Location: tilat.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lisää tila</title>
</head>
<body>
    <h1>Lisää uusi tila</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" required><br>
        Kapasiteetti: <input type="number" name="kapasiteetti" required><br>
        <input type="submit" value="Lisää
