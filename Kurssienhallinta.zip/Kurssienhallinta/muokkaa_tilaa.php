<?php
include 'db.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $kapasiteetti = $_POST['kapasiteetti'];

    $sql = "UPDATE tilat SET nimi='$nimi', kapasiteetti='$kapasiteetti' WHERE tila_id='$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: tilat.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
} else {
    $sql = "SELECT * FROM tilat WHERE tila_id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Muokkaa tilaa</title>
</head>
<body>
    <h1>Muokkaa tilaa</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" value="<?php echo $row['nimi']; ?>" required><br>
        Kapasiteetti: <input type="number" name="kapasiteetti" value="<?php echo $row['kapasiteetti']; ?>" required><br>
        <input type="submit" value="Tallenna">
    </form>
</body>
</html>
