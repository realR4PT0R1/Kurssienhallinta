<?php
include 'db.php';

$sql = "SELECT * FROM opiskelijat";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Opiskelijat</title>
</head>
<body>
    <h1>Opiskelijat</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Vuosikurssi</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // Oletetaan, että kentät ovat 'etunimi', 'sukunimi', 'vuosikurssi' ja 'opiskelija_id'
                $opiskelija_nimi = $row['etunimi'] . ' ' . $row['sukunimi']; // Yhdistetään etunimi ja sukunimi
                $vuosikurssi = $row['vuosikurssi']; // Hakee vuosikurssin

                echo "<tr>
                        <td>{$opiskelija_nimi}</td>
                        <td>{$vuosikurssi}</td>
                        <td>
                            <a href='muokkaa_opiskelijaa.php?id={$row['opiskelija_id']}'>Muokkaa</a> |
                            <a href='poista_opiskelija.php?id={$row['opiskelija_id']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Ei opiskelijoita</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_opiskelija.php">Lisää uusi opiskelija</a>
</body>
</html>
