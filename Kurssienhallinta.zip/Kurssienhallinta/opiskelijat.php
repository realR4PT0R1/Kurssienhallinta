<?php
include 'db.php';

$sql = "SELECT * FROM opiskelijat";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Opiskelijat</title>
</head>

<body>
    <h1>Opiskelijat</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Vuosikurssi</th>
            <th>Kurssit</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $opiskelija_nimi = $row['Etunimi'] . ' ' . $row['Sukunimi']; // Yhdistetään etunimi ja sukunimi
                $vuosikurssi = $row['Vuosikurssi']; // Hakee vuosikurssin
        
                echo "<tr>
                        <td>{$opiskelija_nimi}</td>
                        <td>{$vuosikurssi}</td>
                        <td>";

                // Hae opiskelijan kirjautuneet kurssit
                $opiskelija_id = $row['Opiskelijanumero'];
                $kurssitSql = "SELECT kurssit.Kurssi, kurssit.Alkupäivä
                               FROM kirjautuneet
                               JOIN kurssit ON kirjautuneet.Kurssi = kurssit.Kurssi
                               WHERE kirjautuneet.Tunnus = $opiskelija_id";
                $kurssitResult = $conn->query($kurssitSql);

                if ($kurssitResult->num_rows > 0) {
                    echo "<ul>";
                    while ($kurssi = $kurssitResult->fetch_assoc()) {
                        echo "<li>{$kurssi['Kurssi']} - Aloituspäivämäärä: {$kurssi['Alkupäivä']}</li>";
                    }
                    echo "</ul>";
                } else {
                    echo "Ei kirjautuneita kursseja";
                }

                echo "</td>
                        <td>
                            <a href='muokkaa_opiskelijaa.php?id={$row['Opiskelijanumero']}'>Muokkaa</a> |
                            <a href='poista_opiskelija.php?id={$row['Opiskelijanumero']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Ei opiskelijoita</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_opiskelija.php">Lisää uusi opiskelija</a>
</body>

</html>