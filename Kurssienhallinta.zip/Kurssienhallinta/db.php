<?php
$servername = "localhost";
$username = "lauri";  // Päivitä käyttäjänimi ja salasana
$password = "Taskulamppu";
$database = "kurssienhallinta";  // Päivitä tietokannan nimi

// Luo yhteys
$conn = new mysqli($servername, $username, $password, $database);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteys epäonnistui: " . $conn->connect_error);
}
?>
