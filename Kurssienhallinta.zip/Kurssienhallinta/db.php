<?php
$servername = "localhost";
$username = "root";  // Päivitä käyttäjänimi ja salasana
$password = "";
$database = "kurssienhallinta";  // Päivitä tietokannan nimi

// Luo yhteys
$conn = new mysqli($servername, $username, $password, $database);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteys epäonnistui: " . $conn->connect_error);
}
?>
