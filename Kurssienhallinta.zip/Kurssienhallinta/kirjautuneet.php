<?php
// Yhdistä tietokantaan
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kurssienhallinta";

$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteyden muodostaminen epäonnistui: " . $conn->connect_error);
}

// Hae kaikki kirjautuneet
$sql = "SELECT * FROM kirjautuneet";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kirjautuneet - Muokkaa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Kirjautuneet henkilöt</h1>

    <table>
        <tr>
            <th>Oppilaan nimi</th>
            <th>Kurssi</th>
            <th>Kirjautumis päivä</th>
            <th>Kirjautumis aika</th>
            <th>Muokkaa</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            // Tulostaa jokaisen rivin
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["Oppilaan_nimi"] . "</td>";
                echo "<td>" . $row["Kurssi"] . "</td>";
                echo "<td>" . $row["Kirjautumis_päivä"] . "</td>";
                echo "<td>" . $row["Kirjautumis_aika"] . "</td>";
                echo "<td><a href='muokkaa_kirjautuneet.php?Tunnus=" . $row["Tunnus"] . "'>Muokkaa</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Ei kirjautuneita.</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
