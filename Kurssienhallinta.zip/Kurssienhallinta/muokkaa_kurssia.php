<?php
include 'db.php';

$id = $_GET['id']; // Haetaan kurssin tunnus URL:sta

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Haetaan lomakkeesta lähetetyt tiedot
    $Kurssi = $_POST['nimi'];
    $Kuvaus = $_POST['kuvaus'];
    $Alkupäivä = $_POST['aloituspaiva'];
    $Loppupäivä = $_POST['lopetuspaiva'];
    $Opettaja = $_POST['opettaja_id']; // Opettajan ID
    $Tila = $_POST['tila_id']; // Kurssin tila

    // Päivitetään kurssin tiedot tietokantaan
    $sql = "UPDATE kurssit 
            SET Kurssi='$Kurssi', Kuvaus='$Kuvaus', Alkupäivä='$Alkupäivä', Loppupäivä='$Loppupäivä', Opettaja='$Opettaja', Tila='$Tila' 
            WHERE Tunnus='$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: kurssit.php"); // Siirrytään takaisin kurssien listalle
        exit();
    } else {
        echo "Virhe: " . $conn->error; // Jos tapahtuu virhe, näytetään virheilmoitus
    }
} else {
    // Haetaan kurssin tiedot tietokannasta
    $sql = "SELECT * FROM kurssit WHERE Tunnus='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}

// Haetaan opettajat ja tilat tietokannasta
$sql_opettajat = "SELECT * FROM opettajat";
$result_opettajat = $conn->query($sql_opettajat);

$sql_tilat = "SELECT * FROM tilat";
$result_tilat = $conn->query($sql_tilat);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Muokkaa kurssia</title>
</head>

<body>
    <h1>Muokkaa kurssia</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" value="<?php echo htmlspecialchars($row['Kurssi']); ?>" required><br>
        Kuvaus: <textarea name="kuvaus" required><?php echo htmlspecialchars($row['Kuvaus']); ?></textarea><br>
        Aloituspäivä: <input type="date" name="aloituspaiva" value="<?php echo htmlspecialchars($row['Alkupäivä']); ?>"
            required><br>
        Lopetuspäivä: <input type="date" name="lopetuspaiva" value="<?php echo htmlspecialchars($row['Loppupäivä']); ?>"
            required><br>

        <!-- Opettajan valinta -->
        Opettaja:
        <select name="opettaja_id" required>
            <?php while ($opettaja = $result_opettajat->fetch_assoc()) { ?>
                <option value="<?php echo $opettaja['Tunnusnumero']; ?>" <?php echo ($opettaja['Tunnusnumero'] == $row['Opettaja']) ? 'selected' : ''; ?>>
                    <?php echo $opettaja['Etunimi'] . ' ' . $opettaja['Sukunimi']; ?>
                </option>
            <?php } ?>
        </select><br>

        <!-- Tilavalinta -->
        Tila:
        <select name="tila_id" required>
            <?php while ($tila = $result_tilat->fetch_assoc()) { ?>
                <option value="<?php echo $tila['Tunnus']; ?>" <?php echo ($tila['Tunnus'] == $row['Tila']) ? 'selected' : ''; ?>>
                    <?php echo $tila['Nimi']; ?> - <?php echo $tila['Tunnus']; ?>
                </option>
            <?php } ?>
        </select><br>

        <input type="submit" value="Tallenna">
    </form>
</body>

</html>