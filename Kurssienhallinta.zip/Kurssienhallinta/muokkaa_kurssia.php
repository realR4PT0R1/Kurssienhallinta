<?php
include 'db.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $kuvaus = $_POST['kuvaus'];
    $aloituspaiva = $_POST['aloituspaiva'];
    $lopetuspaiva = $_POST['lopetuspaiva'];
    $opettaja_id = $_POST['opettaja_id'];
    $tila_id = $_POST['tila_id'];

    $sql = "UPDATE kurssit SET nimi='$nimi', kuvaus='$kuvaus', aloituspaiva='$aloituspaiva', lopetuspaiva='$lopetuspaiva', opettaja_id='$opettaja_id', tila_id='$tila_id' WHERE kurssi_id='$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: kurssit.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
} else {
    $sql = "SELECT * FROM kurssit WHERE kurssi_id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Muokkaa kurssia</title>
</head>
<body>
    <h1>Muokkaa kurssia</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" value="<?php echo $row['nimi']; ?>" required><br>
        Kuvaus: <textarea name="kuvaus" required><?php echo $row['kuvaus']; ?></textarea><br>
        Aloituspäivä: <input type="date" name="aloituspaiva" value="<?php echo $row['aloituspaiva']; ?>" required><br>
        Lopetuspäivä: <input type="date" name="lopetuspaiva" value="<?php echo $row['lopetuspaiva']; ?>" required><br>
        Opettaja: <input type="number" name="opettaja_id" value="<?php echo $row['opettaja_id']; ?>" required><br>
        Tila: <input type="number" name="tila_id" value="<?php echo $row['tila_id']; ?>" required><br>
        <input type="submit" value="Tallenna">
    </form>
</body>
</html>
