<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM kurssit WHERE kurssi_id='$id'";

if ($conn->query($sql) === TRUE) {
    header("Location: kurssit.php");
} else {
    echo "Virhe: " . $conn->error;
}
?>
