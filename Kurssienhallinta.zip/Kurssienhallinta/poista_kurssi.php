<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Tarkista, onko id-numero oikea
    if (is_numeric($id)) {
        $sql = "DELETE FROM kurssit WHERE Tunnus = '$id'";

        if ($conn->query($sql) === TRUE) {
            echo "Kurssi poistettu!";
            header("Location: kurssit.php"); // Uudelleenohjaa kursseihin
        } else {
            echo "Virhe: " . $conn->error;
        }
    } else {
        echo "Virheellinen ID!";
    }
} else {
    echo "ID-parametri puuttuu!";
}
?>