<?php
// Yhdistä tietokantaan
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kurssienhallinta";

$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteyden muodostaminen epäonnistui: " . $conn->connect_error);
}

// Hae kirjautuneen tiedot, jonka Tunnus on URL-parametrissa
if (isset($_GET['Tunnus'])) {
    $tunnus = $_GET['Tunnus'];

    $sql = "SELECT * FROM kirjautuneet WHERE Tunnus = $tunnus";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Haetaan rivin tiedot
        $row = $result->fetch_assoc();
        $opiskelaan_nimi = $row["Oppilaan_nimi"];
        $kurssi = $row["Kurssi"];
        $kirjautumis_paiva = $row["Kirjautumis_päivä"];
        $kirjautumis_aika = $row["Kirjautumis_aika"];
    } else {
        echo "Ei löytynyt tietoja.";
        exit;
    }
} else {
    echo "Ei tunnistettua käyttäjää.";
    exit;
}

// Päivitetään tiedot lomakkeen lähetyksellä
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $opiskelaan_nimi = $_POST["Oppilaan_nimi"];
    $kurssi = $_POST["Kurssi"];
    $kirjautumis_paiva = $_POST["Kirjautumis_päivä"];
    $kirjautumis_aika = $_POST["Kirjautumis_aika"];

    $sql = "UPDATE kirjautuneet SET Oppilaan_nimi='$opiskelaan_nimi', Kurssi='$kurssi', Kirjautumis_päivä='$kirjautumis_paiva', Kirjautumis_aika='$kirjautumis_aika' WHERE Tunnus=$tunnus";

    if ($conn->query($sql) === TRUE) {
        echo "Tiedot päivitetty onnistuneesti.";
    } else {
        echo "Virhe päivityksessä: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Muokkaa kirjautunutta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="date"], input[type="time"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Muokkaa kirjautunutta</h1>
    <form method="POST" action="muokkaa_kirjautuneet.php?Tunnus=<?php echo $tunnus; ?>">
        <div class="form-group">
            <label for="Oppilaan_nimi">Oppilaan nimi:</label>
            <input type="text" id="Oppilaan_nimi" name="Oppilaan_nimi" value="<?php echo $opiskelaan_nimi; ?>" required>
        </div>
        <div class="form-group">
            <label for="Kurssi">Kurssi:</label>
            <input type="text" id="Kurssi" name="Kurssi" value="<?php echo $kurssi; ?>" required>
        </div>
        <div class="form-group">
            <label for="Kirjautumis_päivä">Kirjautumis päivä:</label>
            <input type="date" id="Kirjautumis_päivä" name="Kirjautumis_päivä" value="<?php echo $kirjautumis_paiva; ?>" required>
        </div>
        <div class="form-group">
            <label for="Kirjautumis_aika">Kirjautumis aika:</label>
            <input type="time" id="Kirjautumis_aika" name="Kirjautumis_aika" value="<?php echo $kirjautumis_aika; ?>" required>
        </div>
        <input type="submit" value="Tallenna muutokset">
    </form>
</body>
</html>

<?php
$conn->close();
?>
