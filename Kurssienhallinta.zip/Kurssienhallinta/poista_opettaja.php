<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM opettajat WHERE opettaja_id='$id'";

if ($conn->query($sql) === TRUE) {
    header("Location: opettajat.php");
} else {
    echo "Virhe: " . $conn->error;
}
?>
