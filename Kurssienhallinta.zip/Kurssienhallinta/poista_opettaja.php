<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Poista opettaja
    $sql = "DELETE FROM opettajat WHERE Tunnusnumero = $id"; // Oikea sarakkeen nimi
    if ($conn->query($sql) === TRUE) {
        echo "Opettaja poistettu onnistuneesti.";
    } else {
        echo "Virhe poistamisessa: " . $conn->error;
    }
} else {
    echo "Virheellinen ID.";
}
?>