<?php
include 'db.php';

// SQL-kysely, joka hakee opettajien tiedot sekä heihin liittyvien kurssien alku- ja loppupäivämäärät
$sql = "SELECT opettajat.Tunnusnumero, opettajat.Etunimi, opettajat.Sukunimi, opettajat.Aine, kurssit.Alkupäivä, kurssit.Loppupäivä 
        FROM opettajat
        LEFT JOIN kurssit ON opettajat.Tunnusnumero = kurssit.Opettaja";  // Oletan, että "Opettaja" viittaa opettajan Tunnusnumeroon

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Opettajat</title>
</head>

<body>
    <h1>Opettajat</h1>
    <table border="1">
        <tr>
            <th>Opettajan nimi</th>
            <th>Aine</th>
            <th>Kurssin alkupäivä</th>
            <th>Kurssin loppupäivä</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Yhdistetään opettajan etunimi ja sukunimi
                $opettaja_nimi = $row['Etunimi'] . ' ' . $row['Sukunimi'];

                // Tulostetaan opettajan tiedot, kurssin alkupäivä ja loppupäivä sekä toiminnot
                echo "<tr>
                        <td>{$opettaja_nimi}</td>
                        <td>{$row['Aine']}</td>
                        <td>{$row['Alkupäivä']}</td>
                        <td>{$row['Loppupäivä']}</td>
                        <td>
                            <a href='muokkaa_opettajaa.php?id={$row['Tunnusnumero']}'>Muokkaa</a> |
                            <a href='poista_opettaja.php?id={$row['Tunnusnumero']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Ei opettajia</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_opettaja.php">Lisää uusi opettaja</a>
</body>

</html>