<?php
include 'db.php';

$sql = "SELECT * FROM opettajat";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Opettajat</title>
</head>
<body>
    <h1>Opettajat</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Aine</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // Yhdistetään etunimi ja sukunimi
                $opettaja_nimi = $row['Etunimi'] . ' ' . $row['Sukunimi'];
                $aine = $row['Aine']; // Hae aine

                echo "<tr>
                        <td>{$opettaja_nimi}</td>
                        <td>{$aine}</td>
                        <td>
                            <a href='muokkaa_opettajaa.php?id={$row['Tunnusnumero']}'>Muokkaa</a> |
                            <a href='poista_opettaja.php?id={$row['Tunnusnumero']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Ei opettajia</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_opettaja.php">Lisää uusi opettaja</a>
</body>
</html>
