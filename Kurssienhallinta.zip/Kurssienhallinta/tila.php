<?php
include 'db.php';

$tila_id = $_GET['id'];

// Haetaan tilan tiedot
$sql = "SELECT nimi, kapasiteetti FROM tilat WHERE Tunnus = '$tila_id'";
$result = $conn->query($sql);
$tila = $result->fetch_assoc();

// Haetaan kurssit, jotka pidetään tässä tilassa
$sql_kurssit = "SELECT kurssit.nimi AS kurssi_nimi, alku_pvm, loppu_pvm, opettajat.nimi AS opettajan_nimi, 
                COUNT(ilmoittautumiset.opiskelija_id) AS osallistujat 
                FROM kurssit 
                JOIN opettajat ON kurssit.opettaja_id = opettajat.opettaja_id 
                LEFT JOIN ilmoittautumiset ON kurssit.kurssi_id = ilmoittautumiset.kurssi_id 
                WHERE kurssit.tila_id = '$tila_id' 
                GROUP BY kurssit.kurssi_id";
$result_kurssit = $conn->query($sql_kurssit);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tilan tiedot</title>
</head>

<body>
    <h1><?php echo $tila['nimi']; ?></h1>
    <p><strong>Kapasiteetti:</strong> <?php echo $tila['kapasiteetti']; ?></p>

    <h2>Tässä tilassa pidettävät kurssit</h2>
    <table border="1">
        <tr>
            <th>Kurssi</th>
            <th>Alkupäivämäärä</th>
            <th>Loppupäivämäärä</th>
            <th>Opettaja</th>
            <th>Osallistujien määrä</th>
        </tr>
        <?php
        if ($result_kurssit->num_rows > 0) {
            while ($row = $result_kurssit->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['kurssi_nimi']}</td>
                        <td>{$row['alku_pvm']}</td>
                        <td>{$row['loppu_pvm']}</td>
                        <td>{$row['opettajan_nimi']}</td>
                        <td>{$row['osallistujat']}";
                // Jos osallistujia on enemmän kuin kapasiteetti, näytetään varoituskuvake
                if ($row['osallistujat'] > $tila['kapasiteetti']) {
                    echo " <img src='warning.png' alt='Varoitus' />";
                }
                echo "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Ei kursseja</td></tr>";
        }
        ?>
    </table>
</body>

</html>