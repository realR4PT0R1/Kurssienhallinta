<?php
include 'db.php';

$opiskelija_id = $_GET['id'];

$sql = "SELECT nimi, vuosikurssi FROM opiskelijat WHERE opiskelija_id = '$opiskelija_id'";
$result = $conn->query($sql);
$opiskelija = $result->fetch_assoc();

$sql_kurssit = "SELECT kurssit.nimi, alku_pvm FROM ilmoittautumiset 
                JOIN kurssit ON ilmoittautumiset.kurssi_id = kurssit.kurssi_id 
                WHERE opiskelija_id = '$opiskelija_id'";
$result_kurssit = $conn->query($sql_kurssit);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Opiskelijan tiedot</title>
</head>
<body>
    <h1><?php echo $opiskelija['nimi']; ?></h1>
    <p><strong>Vuosikurssi:</strong> <?php echo $opiskelija['vuosikurssi']; ?></p>

    <h2>Ilmoittautuneet kurssit</h2>
    <table border="1">
        <tr>
            <th>Kurssi</th>
            <th>Alku päivämäärä</th>
        </tr>
        <?php
        if ($result_kurssit->num_rows > 0) {
            while($row = $result_kurssit->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['nimi']}</td>
                        <td>{$row['alku_pvm']}</td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='2'>Ei ilmoittautuneita kursseja</td></tr>";
        }
        ?>
    </table>
</body>
</html>
