<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM opiskelijat WHERE opiskelija_id='$id'";

if ($conn->query($sql) === TRUE) {
    header("Location: opiskelijat.php");
} else {
    echo "Virhe: " . $conn->error;
}
?>
