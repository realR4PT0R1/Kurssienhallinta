<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Oletetaan, että sarakkeen nimi on 'opiskelijanumero'
    $sql = "DELETE FROM opiskelijat WHERE opiskelijanumero = ?";  // Varmista, että sarakkeen nimi on oikein

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id); // "i" tarkoittaa integeriä
        if ($stmt->execute()) {
            echo "Opiskelija poistettu onnistuneesti.";
        } else {
            echo "Poisto epäonnistui: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Virhe kyselyssä: " . $conn->error;
    }
} else {
    echo "ID:tä ei ole asetettu.";
}
?>