<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $vuosikurssi = $_POST['vuosikurssi'];

    $sql = "INSERT INTO opiskelijat (nimi, vuosikurssi) VALUES ('$nimi', '$vuosikurssi')";

    if ($conn->query($sql) === TRUE) {
        header("Location: opiskelijat.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lisää opiskelija</title>
</head>
<body>
    <h1>Lisää uusi opiskelija</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" required><br>
        Vuosikurssi: <input type="number" name="vuosikurssi" required><br>
        <input type="submit" value="Lisää">
    </form>
</body>
</html>
