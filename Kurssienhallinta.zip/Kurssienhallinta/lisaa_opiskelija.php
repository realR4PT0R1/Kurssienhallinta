<?php
include 'db.php';  // Yhdistetään tietokantaan

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $etunimi = $_POST['etunimi'];
    $sukunimi = $_POST['sukunimi'];
    $vuosikurssi = $_POST['vuosikurssi'];

    // Tarkista, että sarakkeiden nimet vastaavat tietokannan taulua
    $sql = "INSERT INTO opiskelijat (Etunimi, Sukunimi, Vuosikurssi) VALUES ('$etunimi', '$sukunimi', '$vuosikurssi')";

    if ($conn->query($sql) === TRUE) {
        echo "Opettaja lisätty onnistuneesti!";
    } else {
        echo "Virhe lisäyksessä: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Lisää opiskelija</title>
</head>

<body>
    <h1>Lisää opiskelija</h1>
    <form method="POST" action="">
        Etunimi: <input type="text" name="etunimi" required><br>
        Sukunimi: <input type="text" name="sukunimi" required><br>
        Vuosikurssi: <input type="text" name="vuosikurssi" required><br>
        <input type="submit" value="Lisää">
    </form>
</body>

</html>