<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Haetaan lomakkeesta lähetetyt tiedot ja puhdistetaan ne
    $Kurssi = htmlspecialchars($_POST['kurssi']);
    $Kuvaus = htmlspecialchars($_POST['kuvaus']);
    $Alkupäivä = $_POST['alkupaiva'];
    $Loppupäivä = $_POST['loppupaiva'];
    $Opettaja = $_POST['opettaja_id']; // Opettajan ID
    $Tila = $_POST['tila_id']; // Kurssin tila

    // Valmistellaan SQL-lause
    if ($stmt = $conn->prepare("INSERT INTO kurssit (Kurssi, Kuvaus, Alkupäivä, Loppupäivä, Opettaja, Tila) 
        VALUES (?, ?, ?, ?, ?, ?)")) {
        // Sidotaan parametrit
        $stmt->bind_param("ssssii", $Kurssi, $Kuvaus, $Alkupäivä, $Loppupäivä, $Opettaja, $Tila);
        
        // Suoritetaan kysely
        if ($stmt->execute()) {
            echo "Kurssi lisätty onnistuneesti!";
        } else {
            echo "Virhe: " . $stmt->error; // Jos tapahtuu virhe, näytetään virheilmoitus
        }

        // Suljetaan lause
        $stmt->close();
    } else {
        echo "Virhe: " . $conn->error; // Jos lauseen valmistelu epäonnistuu
    }
}
?>

<!DOCTYPE html>
<html lang="fi">

<head>
    <meta charset="UTF-8">
    <title>Lisää Kurssi</title>
</head>

<body>
    <h1>Lisää uusi kurssi</h1>
    <form method="post" action="">
        <label for="kurssi">Kurssin nimi:</label><br>
        <input type="text" id="kurssi" name="kurssi" required><br><br>

        <label for="kuvaus">Kuvaus:</label><br>
        <textarea id="kuvaus" name="kuvaus" required></textarea><br><br>

        <label for="alkupaiva">Alkupäivämäärä:</label><br>
        <input type="date" id="alkupaiva" name="alkupaiva" required><br><br>

        <label for="loppupaiva">Loppupäivämäärä:</label><br>
        <input type="date" id="loppupaiva" name="loppupaiva" required><br><br>

        <!-- Opettajan valinta -->
        <label for="opettaja_id">Opettaja:</label><br>
        <select name="opettaja_id" id="opettaja_id" required>
            <?php
            // Hae opettajat tietokannasta
            $sql_opettajat = "SELECT * FROM opettajat";
            $result_opettajat = $conn->query($sql_opettajat);

            // Käy läpi kaikki opettajat ja luo valikko
            while ($opettaja = $result_opettajat->fetch_assoc()) {
                echo "<option value='" . $opettaja['Tunnusnumero'] . "'>" . $opettaja['Etunimi'] . " " . $opettaja['Sukunimi'] . " (" . $opettaja['Aine'] . ")</option>";
            }
            ?>
        </select><br><br>

        <!-- Tilavalinta -->
        <label for="tila_id">Tila:</label><br>
        <select name="tila_id" id="tila_id" required>
            <?php
            // Hae tilat tietokannasta
            $sql_tilat = "SELECT * FROM tilat";
            $result_tilat = $conn->query($sql_tilat);

            // Käy läpi kaikki tilat ja luo valikko
            while ($tila = $result_tilat->fetch_assoc()) {
                echo "<option value='" . $tila['Tunnus'] . "'>" . $tila['Nimi'] . " (" . $tila['Kapasiteetti'] . " henkilöä)</option>";
            }
            ?>
        </select><br><br>

        <input type="submit" value="Lisää kurssi">
    </form>
</body>

</html>
