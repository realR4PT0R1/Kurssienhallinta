<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $kuvaus = $_POST['kuvaus'];
    $aloituspaiva = $_POST['aloituspaiva'];
    $lopetuspaiva = $_POST['lopetuspaiva'];
    $opettaja_id = $_POST['opettaja_id'];
    $tila_id = $_POST['tila_id'];

    $sql = "INSERT INTO kurssit (nimi, kuvaus, aloituspaiva, lopetuspaiva, opettaja_id, tila_id)
            VALUES ('$nimi', '$kuvaus', '$aloituspaiva', '$lopetuspaiva', '$opettaja_id', '$tila_id')";

    if ($conn->query($sql) === TRUE) {
        header("Location: kurssit.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lisää kurssi</title>
</head>
<body>
    <h1>Lisää uusi kurssi</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" required><br>
        Kuvaus: <textarea name="kuvaus" required></textarea><br>
        Aloituspäivä: <input type="date" name="aloituspaiva" required><br>
        Lopetuspäivä: <input type="date" name="lopetuspaiva" required><br>
        Opettaja: <input type="number" name="opettaja_id" required><br>
        Tila: <input type="number" name="tila_id" required><br>
        <input type="submit" value="Lisää">
    </form>
</body>
</html>
