<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kurssi = $_POST['kurssi'];
    $kuvaus = $_POST['kuvaus'];
    $alkupaiva = $_POST['alkupaiva'];
    $loppupaiva = $_POST['loppupaiva'];
    $opettaja = $_POST['opettaja'];
    $tila = $_POST['tila'];

    $sql = "INSERT INTO kurssit (Kurssi, Kuvaus, Alkupaiva, Loppupaiva, Opettaja, Tila) 
            VALUES ('$kurssi', '$kuvaus', '$alkupaiva', '$loppupaiva', '$opettaja', '$tila')";

    if ($conn->query($sql) === TRUE) {
        echo "Kurssi lisätty onnistuneesti!";
    } else {
        echo "Virhe: " . $conn->error;
    }
}
?>


<!DOCTYPE html>
<html lang="fi">

<head>
    <meta charset="UTF-8">
    <title>Lisää Kurssi</title>
</head>

<body>
    <h1>Lisää uusi kurssi</h1>
    <form method="post" action="">
        <label for="kurssi">Kurssin nimi:</label><br>
        <input type="text" id="kurssi" name="kurssi" required><br><br>

        <label for="kuvaus">Kuvaus:</label><br>
        <textarea id="kuvaus" name="kuvaus" required></textarea><br><br>

        <label for="alkupaiva">Alkupäivämäärä:</label><br>
        <input type="date" id="alkupaiva" name="alkupaiva" required><br><br>

        <label for="loppupaiva">Loppupäivämäärä:</label><br>
        <input type="date" id="loppupaiva" name="loppupaiva" required><br><br>

        <label for="opettaja">Opettaja:</label><br>
        <input type="text" id="opettaja" name="opettaja" required><br><br>

        <label for="tila">Tila:</label><br>
        <input type="text" id="tila" name="tila" required><br><br>

        <input type="submit" value="Lisää kurssi">
    </form>
</body>

</html>