<!DOCTYPE html>
<html>
<head>
    <title>Kurssienhallinta - Etusivu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #333;
        }
        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            text-align: center;
            background-color: #f9f9f9;
        }
        .card a {
            display: block;
            padding: 10px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            border-radius: 3px;
            margin-top: 10px;
        }
        .card a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Kurssienhallinta</h1>
    <div class="card">
        <h2>Opettajat</h2>
        <p>Hallinnoi opettajia: lisää, muokkaa ja poista opettajia.</p>
        <a href="opettajat.php">Siirry opettajiin</a>
    </div>

    <div class="card">
        <h2>Opiskelijat</h2>
        <p>Hallinnoi opiskelijoita: lisää, muokkaa ja poista opiskelijoita.</p>
        <a href="opiskelijat.php">Siirry opiskelijoihin</a>
    </div>

    <div class="card">
        <h2>Kurssit</h2>
        <p>Hallinnoi kursseja: lisää, muokkaa ja poista kursseja.</p>
        <a href="kurssit.php">Siirry kursseihin</a>
    </div>

    <div class="card">
        <h2>Tilat</h2>
        <p>Hallinnoi tiloja: lisää, muokkaa ja poista tiloja.</p>
        <a href="tilat.php">Siirry tiloihin</a>
    </div>
</body>
</html>
