<?php
include 'db.php';  // Yhdistetään tietokantaan

// Haetaan opiskelija opiskelijanumerolla
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Muokkaa kyselyä käyttäen oikeaa sarakkeen nimeä, tässä esimerkissä 'Opiskelijanumero'
    $sql = "SELECT * FROM opiskelijat WHERE Opiskelijanumero = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id); // "i" tarkoittaa integeriä
        $stmt->execute();
        $result = $stmt->get_result();

        // Tarkistetaan, löytyikö opiskelija
        if ($result->num_rows > 0) {
            // Tässä on opiskelija tiedot
            $row = $result->fetch_assoc();

            // Täytetään lomakkeen kentät opiskelijan tiedoilla
            $etunimi = isset($row['Etunimi']) ? $row['Etunimi'] : '';
            $sukunimi = isset($row['Sukunimi']) ? $row['Sukunimi'] : '';
            $syntymapaiva = isset($row['Syntymäpäivä']) ? $row['Syntymäpäivä'] : '';
            $vuosikurssi = isset($row['Vuosikurssi']) ? $row['Vuosikurssi'] : '';
        } else {
            echo "Opiskelijaa ei löydy.";
        }
    } else {
        echo "Virhe kyselyssä: " . $conn->error;
    }
} else {
    echo "ID:tä ei ole asetettu.";
}

// Lomakkeen tietojen päivitys
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Haetaan lomakkeen tiedot
    $etunimi = $_POST['etunimi'];
    $sukunimi = $_POST['sukunimi'];
    $syntymapaiva = $_POST['syntymapaiva'];
    $vuosikurssi = $_POST['vuosikurssi'];

    // Päivitetään opiskelijan tiedot tietokannassa
    $update_sql = "UPDATE opiskelijat SET Etunimi = ?, Sukunimi = ?, Syntymäpäivä = ?, Vuosikurssi = ? WHERE Opiskelijanumero = ?";
    if ($update_stmt = $conn->prepare($update_sql)) {
        $update_stmt->bind_param("ssssi", $etunimi, $sukunimi, $syntymapaiva, $vuosikurssi, $id); // "s" tarkoittaa stringiä ja "i" tarkoittaa integeriä
        if ($update_stmt->execute()) {
            echo "Opiskelija päivitetty onnistuneesti.";
        } else {
            echo "Virhe päivityksessä: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Muokkaa opiskelijaa</title>
</head>

<body>
    <h1>Muokkaa opiskelijaa</h1>
    <form method="POST" action="">
        Etunimi: <input type="text" name="etunimi" value="<?php echo htmlspecialchars($etunimi); ?>" required><br>
        Sukunimi: <input type="text" name="sukunimi" value="<?php echo htmlspecialchars($sukunimi); ?>" required><br>
        Syntymäpäivä: <input type="date" name="syntymapaiva" value="<?php echo htmlspecialchars($syntymapaiva); ?>"
            required><br>
        Vuosikurssi: <input type="number" name="vuosikurssi" value="<?php echo htmlspecialchars($vuosikurssi); ?>"
            required><br>
        <input type="submit" value="Tallenna">
    </form>
</body>

</html>