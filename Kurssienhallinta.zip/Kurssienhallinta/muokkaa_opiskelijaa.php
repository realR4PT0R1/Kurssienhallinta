<?php
include 'db.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $vuosikurssi = $_POST['vuosikurssi'];

    $sql = "UPDATE opiskelijat SET nimi='$nimi', vuosikurssi='$vuosikurssi' WHERE opiskelija_id='$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: opiskelijat.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
} else {
    $sql = "SELECT * FROM opiskelijat WHERE opiskelija_id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Muokkaa opiskelijaa</title>
</head>
<body>
    <h1>Muokkaa opiskelijaa</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" value="<?php echo $row['nimi']; ?>" required><br>
        Vuosikurssi: <input type="number" name="vuosikurssi" value="<?php echo $row['vuosikurssi']; ?>" required><br>
        <input type="submit" value="Tallenna">
    </form>
</body>
</html>
