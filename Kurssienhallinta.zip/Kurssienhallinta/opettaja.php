<?php
include 'db.php';

$opettaja_id = $_GET['id'];

$sql = "SELECT nimi, aine FROM opettajat WHERE opettaja_id = '$opettaja_id'";
$result = $conn->query($sql);
$opettaja = $result->fetch_assoc();

$sql_kurssit = "SELECT kurssit.nimi, alku_pvm, loppu_pvm, tilat.nimi AS tilan_nimi 
                FROM kurssit 
                JOIN tilat ON kurssit.tila_id = tilat.tila_id 
                WHERE opettaja_id = '$opettaja_id'";
$result_kurssit = $conn->query($sql_kurssit);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Opettajan tiedot</title>
</head>
<body>
    <h1><?php echo $opettaja['nimi']; ?></h1>
    <p><strong>Aine:</strong> <?php echo $opettaja['aine']; ?></p>

    <h2>Vastattavat kurssit</h2>
    <table border="1">
        <tr>
            <th>Kurssi</th>
            <th>Alku päivämäärä</th>
            <th>Loppu päivämäärä</th>
            <th>Tila</th>
        </tr>
        <?php
        if ($result_kurssit->num_rows > 0) {
            while($row = $result_kurssit->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['nimi']}</td>
                        <td>{$row['alku_pvm']}</td>
                        <td>{$row['loppu_pvm']}</td>
                        <td>{$row['tilan_nimi']}</td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Ei kursseja</td></tr>";
        }
        ?>
    </table>
</body>
</html>
