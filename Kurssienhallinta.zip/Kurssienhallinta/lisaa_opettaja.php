<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nimi = $_POST['nimi'];
    $aine = $_POST['aine'];

    $sql = "INSERT INTO opettajat (nimi, aine) VALUES ('$nimi', '$aine')";

    if ($conn->query($sql) === TRUE) {
        header("Location: opettajat.php");
    } else {
        echo "Virhe: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lisää opettaja</title>
</head>
<body>
    <h1>Lisää uusi opettaja</h1>
    <form method="POST" action="">
        Nimi: <input type="text" name="nimi" required><br>
        Aine: <input type="text" name="aine" required><br>
        <input type="submit" value="Lisää">
    </form>
</body>
</html>
