<?php
include 'db.php';

$sql = "SELECT kurssit.*, opettajat.nimi AS opettaja_nimi, tilat.nimi AS tila_nimi
        FROM kurssit
        JOIN opettajat ON kurssit.opettaja_id = opettajat.opettaja_id
        JOIN tilat ON kurssit.tila_id = tilat.tila_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kurssit</title>
</head>
<body>
    <h1>Kurssit</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Kuvaus</th>
            <th>Aloituspäivä</th>
            <th>Lopetuspäivä</th>
            <th>Opettaja</th>
            <th>Tila</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['nimi']}</td>
                        <td>{$row['kuvaus']}</td>
                        <td>{$row['aloituspaiva']}</td>
                        <td>{$row['lopetuspaiva']}</td>
                        <td>{$row['opettaja_nimi']}</td>
                        <td>{$row['tila_nimi']}</td>
                        <td>
                            <a href='muokkaa_kurssia.php?id={$row['kurssi_id']}'>Muokkaa</a> |
                            <a href='poista_kurssi.php?id={$row['kurssi_id']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>Ei kursseja</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_kurssi.php">Lisää uusi kurssi</a>
</body>
</html>
