<?php
include 'db.php';

// Hae kurssien tiedot ja yhdistä opettajat ja tilat-taulut
$sql = "SELECT kurssit.*, 
            CONCAT(opettajat.Etunimi, ' ', opettajat.Sukunimi) AS Opettaja, 
            tilat.Nimi AS Tila_Nimi, tilat.Tunnus AS Tila_Numero
        FROM kurssit
        LEFT JOIN opettajat ON kurssit.Opettaja = opettajat.Tunnusnumero
        LEFT JOIN tilat ON kurssit.Tila = tilat.Tunnus";

// Suoritetaan SQL-kysely
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Kurssit</title>
</head>

<body>
    <h1>Kurssit</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Kuvaus</th>
            <th>Aloituspäivä</th>
            <th>Lopetuspäivä</th>
            <th>Opettaja</th>
            <th>Tila</th>
            <th>Ilmoittautuneet opiskelijat</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result && $result->num_rows > 0) {
            // Käydään läpi kaikki kurssit ja näytetään ne
            while ($row = $result->fetch_assoc()) {
                // Hae ilmoittautuneet opiskelijat kyseiselle kurssille
                $kurssi = $row['Kurssi'];
                $sql_opiskelijat = "SELECT Oppilaan_nimi FROM kirjautuneet WHERE Kurssi = '$kurssi'";
                $opiskelijat_result = $conn->query($sql_opiskelijat);
                $opiskelijat_list = [];

                if ($opiskelijat_result && $opiskelijat_result->num_rows > 0) {
                    while ($opiskelija = $opiskelijat_result->fetch_assoc()) {
                        $opiskelijat_list[] = $opiskelija['Oppilaan_nimi'];
                    }
                }
                $opiskelijat_str = implode(', ', $opiskelijat_list);

                echo "<tr>
                        <td>{$row['Kurssi']}</td>
                        <td>{$row['Kuvaus']}</td>
                        <td>{$row['Alkupäivä']}</td>
                        <td>{$row['Loppupäivä']}</td>
                        <td>{$row['Opettaja']}</td>
                        <td>{$row['Tila_Nimi']} - {$row['Tila_Numero']}</td>
                        <td>{$opiskelijat_str}</td>
                        <td>
                            <a href='muokkaa_kurssia.php?id={$row['Tunnus']}'>Muokkaa</a> |
                            <a href='poista_kurssi.php?id={$row['Tunnus']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='8'>Ei kursseja</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_kurssi.php">Lisää uusi kurssi</a>
</body>

</html>