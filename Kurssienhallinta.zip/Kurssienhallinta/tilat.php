<?php
include 'db.php';

// Hae kaikki tilat
$sql = "SELECT * FROM tilat";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tilat</title>
</head>

<body>
    <h1>Tilat</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Kapasiteetti</th>
            <th>Kurssit</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Tila-id, jota käytetään kurssien hakemiseen
                $tila_id = $row['Tunnus'];

                // Debugging: Tarkista, että tila_id on oikein
                // echo "<p>Tila ID: $tila_id</p>";
        
                // Hae kurssit tietyssä tilassa
                $sql_kurssit = "SELECT kurssit.Kurssi, kurssit.Kuvaus, kurssit.Alkupäivä, 
                kurssit.Loppupäivä, opettajat.Etunimi AS opettajan_etunimi, 
                opettajat.Sukunimi AS opettajan_sukunimi 
                FROM kurssit 
                JOIN opettajat ON kurssit.Opettaja = opettajat.Tunnusnumero 
                WHERE kurssit.Tila = '$tila_id'";


                // Debugging: Näytä kysely
                // echo "<p>SQL-kysely: $sql_kurssit</p>";
        
                $result_kurssit = $conn->query($sql_kurssit);

                // Näytetään tila ja sen kurssit
                echo "<tr>
                        <td>{$row['Nimi']}</td>
                        <td>{$row['Kapasiteetti']}</td>
                        <td>";

                if ($result_kurssit->num_rows > 0) {
                    while ($course_row = $result_kurssit->fetch_assoc()) {
                        echo "<p><strong>Kurssi:</strong> {$course_row['Kurssi']}</p>
                              <p><strong>Opettaja:</strong> {$course_row['opettajan_etunimi']} {$course_row['opettajan_sukunimi']}</p>
                              <p><strong>Alkupäivämäärä:</strong> {$course_row['Alkupäivä']}</p>
                              <p><strong>Loppupäivämäärä:</strong> {$course_row['Loppupäivä']}</p>
                              <p><strong>Kuvaus:</strong> {$course_row['Kuvaus']}</p>";

                        echo "<hr>";
                    }
                } else {
                    echo "Ei kursseja";
                }

                echo "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Ei tiloja</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_tila.php">Lisää uusi tila</a>
</body>

</html>