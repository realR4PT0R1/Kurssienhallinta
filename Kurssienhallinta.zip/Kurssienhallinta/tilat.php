<?php
include 'db.php';

$sql = "SELECT * FROM tilat";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tilat</title>
</head>
<body>
    <h1>Tilat</h1>
    <table border="1">
        <tr>
            <th>Nimi</th>
            <th>Kapteetti</th>
            <th>Toiminnot</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['nimi']}</td>
                        <td>{$row['kapasiteetti']}</td>
                        <td>
                            <a href='muokkaa_tilaa.php?id={$row['tila_id']}'>Muokkaa</a> |
                            <a href='poista_tila.php?id={$row['tila_id']}'>Poista</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Ei tiloja</td></tr>";
        }
        ?>
    </table>
    <a href="lisaa_tila.php">Lisää uusi tila</a>
</body>
</html>
