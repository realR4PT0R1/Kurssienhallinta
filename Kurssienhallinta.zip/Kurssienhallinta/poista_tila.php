<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM tilat WHERE Tunnus='$id'";

if ($conn->query($sql) === TRUE) {
    header("Location: tilat.php");
} else {
    echo "Virhe: " . $conn->error;
}
?>