<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM tilat WHERE tila_id='$id'";

if ($conn->query($sql) === TRUE) {
    header("Location: tilat.php");
} else {
    echo "Virhe: " . $conn->error;
}
?>
